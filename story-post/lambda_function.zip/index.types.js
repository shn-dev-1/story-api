"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaProcessingType = exports.StoryMetaDataStatus = void 0;
var StoryMetaDataStatus;
(function (StoryMetaDataStatus) {
    StoryMetaDataStatus[StoryMetaDataStatus["PENDING"] = 0] = "PENDING";
    StoryMetaDataStatus[StoryMetaDataStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    StoryMetaDataStatus[StoryMetaDataStatus["POST_PROCESSING"] = 2] = "POST_PROCESSING";
    StoryMetaDataStatus[StoryMetaDataStatus["COMPLETED"] = 3] = "COMPLETED";
})(StoryMetaDataStatus || (exports.StoryMetaDataStatus = StoryMetaDataStatus = {}));
var MediaProcessingType;
(function (MediaProcessingType) {
    MediaProcessingType[MediaProcessingType["IMAGE"] = 0] = "IMAGE";
    MediaProcessingType[MediaProcessingType["VIDEO"] = 1] = "VIDEO";
    MediaProcessingType[MediaProcessingType["AUDIO"] = 2] = "AUDIO";
    MediaProcessingType[MediaProcessingType["TEXT"] = 3] = "TEXT";
})(MediaProcessingType || (exports.MediaProcessingType = MediaProcessingType = {}));
//# sourceMappingURL=index.types.js.map