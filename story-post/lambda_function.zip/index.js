"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const openai_1 = __importDefault(require("openai"));
// Initialize AWS SDK clients
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
const dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const sqs = new client_sqs_1.SQSClient({});
// Initialize OpenAI client
const openai = new openai_1.default({
    apiKey: process.env.OPENAI_API_KEY,
});
const handler = async (event) => {
    try {
        // Parse the incoming request
        const body = JSON.parse(event.body || '{}');
        const payload = body.payload || '';
        const openaiPrompt = body.openaiPrompt || '';
        const model = body.model || 'gpt-4o'; // Default to GPT-4o (closest to GPT-5)
        let openaiResponse;
        // Call OpenAI if a prompt is provided and API key is available
        if (openaiPrompt && process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim() !== '') {
            try {
                const completion = await openai.chat.completions.create({
                    model: model,
                    messages: [
                        {
                            role: "system",
                            content: "You are a helpful AI assistant. Provide clear, concise, and accurate responses."
                        },
                        {
                            role: "user",
                            content: openaiPrompt
                        }
                    ],
                    max_tokens: 1000,
                    temperature: 0.7,
                });
                openaiResponse = completion.choices[0]?.message?.content || undefined;
                console.log('OpenAI API call successful');
            }
            catch (openaiError) {
                console.error('Error calling OpenAI API:', openaiError);
                openaiResponse = 'Error: Unable to get AI response';
            }
        }
        // Send message to SQS queue
        const sqsParams = {
            MessageBody: JSON.stringify({
                storyPayload: payload,
                openaiPrompt: openaiPrompt,
                openaiResponse: openaiResponse,
                timestamp: new Date().toISOString(),
                source: 'story-service-lambda'
            }),
            QueueUrl: process.env.SQS_QUEUE_URL
        };
        try {
            await sqs.send(new client_sqs_1.SendMessageCommand(sqsParams));
            console.log('Message sent to SQS successfully');
        }
        catch (sqsError) {
            console.error('Error sending message to SQS:', sqsError);
        }
        // Store data in DynamoDB
        const dynamoParams = {
            TableName: process.env.DYNAMODB_TABLE,
            Item: {
                id: `story-${Date.now()}`,
                payload: payload,
                openaiPrompt: openaiPrompt,
                openaiResponse: openaiResponse,
                model: model,
                timestamp: new Date().toISOString(),
                status: 'created'
            }
        };
        try {
            await dynamodb.send(new lib_dynamodb_1.PutCommand(dynamoParams));
            console.log('Data stored in DynamoDB successfully');
        }
        catch (dynamoError) {
            console.error('Error storing data in DynamoDB:', dynamoError);
        }
        const response = {
            message: 'Success',
            receivedPayload: payload,
            openaiResponse: openaiResponse,
            note: 'SQS, DynamoDB, and OpenAI operations completed successfully.'
        };
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify(response)
        };
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                message: 'Internal server error',
                error: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map