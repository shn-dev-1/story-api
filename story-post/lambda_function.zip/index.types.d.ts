export interface StoryRequest {
    payload: string;
    openaiPrompt?: string;
    model?: string;
}
export interface StoryResponse {
    message: string;
    receivedPayload: string;
    openaiResponse?: string | undefined;
    note?: string;
}
export declare enum StoryMetaDataStatus {
    PENDING = 0,
    IN_PROGRESS = 1,
    POST_PROCESSING = 2,
    COMPLETED = 3
}
export interface StoryMetaDataDDBItem {
    id: string;
    created_by: string;
    status: StoryMetaDataStatus;
    dateCreated: string;
    dateUpdated: string;
    media_ids: string[];
}
export declare enum MediaProcessingType {
    IMAGE = 0,
    VIDEO = 1,
    AUDIO = 2,
    TEXT = 3
}
export interface SQSMediaProcessingMessage {
    media_id: string;
    media_type: MediaProcessingType;
    story_id: string;
    content: string;
}
//# sourceMappingURL=index.types.d.ts.map